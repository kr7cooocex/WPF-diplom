﻿using PetrenkoSupport.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PetrenkoSupport.Pages
{
    /// <summary>
    /// Логика взаимодействия для HelpPage.xaml
    /// </summary>
    public partial class HelpPage : Page
    {
        public HelpPage()
        {
            InitializeComponent();
        }

        private int selectedRequestTypeId;

        private void btnProductFault_Click(object sender, RoutedEventArgs e)
        {
            selectedRequestTypeId = 1; // "Товар неисправен" имеет ID 1 в таблице Problems
            TbProblem.Visibility = Visibility.Collapsed;
            arrow.Visibility = Visibility.Collapsed;
            describe.Visibility = Visibility.Collapsed;
        }

        private void btnAskQuestion_Click(object sender, RoutedEventArgs e)
        {
            selectedRequestTypeId = 2; // "Задать вопрос" имеет ID 2 в таблице Problems
            TbProblem.Visibility = Visibility.Visible;
            arrow.Visibility = Visibility.Visible;
            describe.Visibility = Visibility.Visible;
        }

        private void btnBugReport_Checked(object sender, RoutedEventArgs e)
        {
            selectedRequestTypeId = 3; // "Сообщить о баге" имеет ID 3 в таблице Problems
            TbProblem.Visibility = Visibility.Visible;
            arrow.Visibility = Visibility.Visible;
            describe.Visibility = Visibility.Visible;
        }

        private void btnIdea_Checked(object sender, RoutedEventArgs e)
        {
            selectedRequestTypeId = 4; // "Предложить идею" имеет ID 4 в таблице Problems
            TbProblem.Visibility = Visibility.Visible;
            arrow.Visibility = Visibility.Visible;
            describe.Visibility = Visibility.Visible;
        }

        private void Send_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (selectedRequestTypeId == 0)
                {
                    MessageBox.Show("Пожалуйста, выберите тип запроса.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                using (var context = new SupportEntities())
                {
                    var HuntShowdown = new Customer_requests
                    {
                        customer_name = TbName.Text,       
                        customer_ask = TbProblem.Text,    
                        phone_number = TbNumber.Text,       
                        problem_id = selectedRequestTypeId  
                    };

                    context.Customer_requests.Add(HuntShowdown);
                    context.SaveChanges();
                }

                MessageBoxResult result = MessageBox.Show(
                    "С вами свяжутся в ближайшее время",
                    "Сообщение",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information
                );

                if (result == MessageBoxResult.OK)
                {
                    this.NavigationService.Navigate(new MainPage());
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    $"Произошла ошибка: {ex.Message}",
                    "Ошибка",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error
                );
            }
        }
        private void Back_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new MainPage());
        }

        
    }
}
