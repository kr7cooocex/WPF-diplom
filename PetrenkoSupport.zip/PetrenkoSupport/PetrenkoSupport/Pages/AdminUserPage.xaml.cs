﻿using PetrenkoSupport.Pages;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using PetrenkoSupport.Model;

namespace PetrenkoSupport.Pages
{
    /// <summary>
    /// Логика взаимодействия для AdminUserPage.xaml
    /// </summary>
    public partial class AdminUserPage : Page
    {
        // Контекст базы данных
        private readonly SupportEntities _dbContext = new SupportEntities();

        public AdminUserPage()
        {
            InitializeComponent();
            LoadData(); // Загрузка данных при инициализации страницы
        }

        // Метод для загрузки данных в DataGrid
        private void LoadData()
        {
            try
            {
                // Запрос данных из базы данных
                var data = from u in _dbContext.Users
                           join r in _dbContext.Role on u.role_id equals r.role_id
                           join d in _dbContext.Departments on u.department_id equals d.department_id
                           select new
                           {
                               u.user_id,
                               u.name,
                               u.date_of_birth,
                               u.rank,
                               Role = r.role_name,
                               Department = d.department_name,
                               u.login,
                               u.password
                           };

                // Привязка данных к DataGrid
                dg.ItemsSource = data.ToList();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new AdminPage());
        }

        private void Dg_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Проверяем, что выбрана строка
            if (dg.SelectedItem != null)
            {
                // Приводим выбранный элемент к типу динамического объекта
                dynamic selectedRow = dg.SelectedItem;

                // Заполняем TextBox-ы данными из выбранной строки
                TbUserName.Text = selectedRow.name;
                TbBirthDate.Text = selectedRow.date_of_birth.ToString("yyyy-MM-dd"); // Форматирование даты
                TbRank.Text = selectedRow.rank;
                TbRoleName.Text = selectedRow.Role;
                TbDepartmentName.Text = selectedRow.Department;
                TbLogin.Text = selectedRow.login;
                TbPassword.Text = selectedRow.password;
            }
        }

    

        // Метод для очистки TextBox-ов после добавления
        private void ClearFields()
        {
            TbUserName.Clear();
            TbBirthDate.Clear();
            TbRank.Clear();
            TbRoleName.Clear();
            TbDepartmentName.Clear();
            TbLogin.Clear();
            TbPassword.Clear();
        }


        private void Change_click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Проверяем, что выбран элемент в DataGrid
                if (dg.SelectedItem == null)
                {
                    MessageBox.Show("Выберите пользователя для обновления.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                // Приводим выбранный элемент к динамическому объекту
                dynamic selectedRow = dg.SelectedItem;

                // Получаем ID пользователя из выбранной строки
                int userId = selectedRow.user_id;

                // Находим пользователя в базе данных
                var user = _dbContext.Users.FirstOrDefault(u => u.user_id == userId);
                if (user == null)
                {
                    MessageBox.Show("Пользователь не найден.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                // Находим роль по названию
                var role = _dbContext.Role.FirstOrDefault(r => r.role_name == TbRoleName.Text);
                if (role == null)
                {
                    MessageBox.Show("Указанная роль не найдена.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                // Находим департамент по названию
                var department = _dbContext.Departments.FirstOrDefault(d => d.department_name == TbDepartmentName.Text);
                if (department == null)
                {
                    MessageBox.Show("Указанный департамент не найден.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                // Обновляем данные пользователя
                user.name = TbUserName.Text;
                user.date_of_birth = DateTime.Parse(TbBirthDate.Text);
                user.rank = TbRank.Text;
                user.role_id = role.role_id;
                user.department_id = department.department_id;
                user.login = TbLogin.Text;
                user.password = TbPassword.Text;

                // Сохраняем изменения в базе данных
                _dbContext.SaveChanges();

                // Оповещаем пользователя об успешном обновлении
                MessageBox.Show("Пользователь успешно обновлён.", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);

                // Обновляем данные в DataGrid
                LoadData();

                // Очищаем поля
                ClearFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при обновлении пользователя: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Delete_click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Проверяем, что выбран элемент в DataGrid
                if (dg.SelectedItem == null)
                {
                    MessageBox.Show("Выберите пользователя для удаления.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                // Приводим выбранный элемент к динамическому объекту
                dynamic selectedRow = dg.SelectedItem;

                // Получаем ID пользователя из выбранной строки
                int userId = selectedRow.user_id;

                // Находим пользователя в базе данных
                var user = _dbContext.Users.FirstOrDefault(u => u.user_id == userId);
                if (user == null)
                {
                    MessageBox.Show("Пользователь не найден.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                // Подтверждение удаления
                var result = MessageBox.Show("Вы уверены, что хотите удалить этого пользователя?", "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Question);
                if (result == MessageBoxResult.No)
                    return;

                // Удаляем пользователя из базы данных
                _dbContext.Users.Remove(user);
                _dbContext.SaveChanges();

                // Оповещаем пользователя об успешном удалении
                MessageBox.Show("Пользователь успешно удалён.", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);

                // Обновляем данные в DataGrid
                LoadData();

                // Очищаем поля
                ClearFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при удалении пользователя: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Add_click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Проверяем, что все обязательные поля заполнены
                if (string.IsNullOrWhiteSpace(TbUserName.Text) ||
                    string.IsNullOrWhiteSpace(TbBirthDate.Text) ||
                    string.IsNullOrWhiteSpace(TbRank.Text) ||
                    string.IsNullOrWhiteSpace(TbRoleName.Text) ||
                    string.IsNullOrWhiteSpace(TbDepartmentName.Text) ||
                    string.IsNullOrWhiteSpace(TbLogin.Text) ||
                    string.IsNullOrWhiteSpace(TbPassword.Text))
                {
                    MessageBox.Show("Заполните все поля перед добавлением.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                // Находим роль по названию
                var role = _dbContext.Role.FirstOrDefault(r => r.role_name == TbRoleName.Text);
                if (role == null)
                {
                    MessageBox.Show("Указанная роль не найдена.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                // Находим департамент по названию
                var department = _dbContext.Departments.FirstOrDefault(d => d.department_name == TbDepartmentName.Text);
                if (department == null)
                {
                    MessageBox.Show("Указанный департамент не найден.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                // Создаем нового пользователя
                var newUser = new Users
                {
                    name = TbUserName.Text,
                    date_of_birth = DateTime.Parse(TbBirthDate.Text),
                    rank = TbRank.Text,
                    role_id = role.role_id,
                    department_id = department.department_id,
                    login = TbLogin.Text,
                    password = TbPassword.Text
                };

                // Добавляем пользователя в базу данных
                _dbContext.Users.Add(newUser);
                _dbContext.SaveChanges(); // Сохраняем изменения в базе данных

                // Оповещаем пользователя об успешном добавлении
                MessageBox.Show("Пользователь успешно добавлен.", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);

                // Обновляем данные в DataGrid
                LoadData();

                // Очищаем поля
                ClearFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при добавлении пользователя: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}