﻿using PetrenkoSupport;
using PetrenkoSupport.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PetrenkoSupport.Pages
{
    /// <summary>
    /// Логика взаимодействия для AdminPage.xaml
    /// </summary>
    public partial class AdminPage : Page
    {
        public AdminPage()
        {
            InitializeComponent();
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new WorkerPage());
        }

        private void Users_click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new AdminUserPage());
        }

        private void Orders_click(object sender, RoutedEventArgs e)
        {

        }
    }
}
