﻿using PetrenkoSupport.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PetrenkoSupport.Pages
{
    /// <summary>
    /// Логика взаимодействия для EmployeePage.xaml
    /// </summary>
    public partial class EmployeePage : Page
    {
        private SupportEntities context = new SupportEntities();

        public EmployeePage()
        {
            InitializeComponent();
            LoadData();
        }

        private void LoadData(string filter = "")
        {
            // LINQ-запрос для объединения данных из всех таблиц
            var query = from request in context.Request_info
                        join customer in context.Customer_requests on request.customer_id equals customer.customer_id
                        join problem in context.Problems on customer.problem_id equals problem.problem_id
                        join status in context.Status on request.status_id equals status.status_id
                        select new
                        {
                            RequestID = request.request_id,
                            CustomerName = customer.customer_name,
                            PhoneNumber = customer.phone_number,
                            CustomerAsk = customer.customer_ask,
                            Problem = problem.problem_name,
                            StatusID = request.status_id,
                            Status = status.status_name
                        };

            // Если фильтр указан, применяем его
            if (!string.IsNullOrWhiteSpace(filter))
            {
                query = query.Where(q => q.CustomerName.Contains(filter) ||
                                         q.Problem.Contains(filter) ||
                                         q.Status.Contains(filter) ||
                                         q.PhoneNumber.Contains(filter));
            }

            // Установка источника данных для DataGrid
            dg.ItemsSource = query.ToList();
        }

        private void dg_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Получение выбранного элемента из DataGrid
            var selectedItem = dg.SelectedItem;
            if (selectedItem != null)
            {
                // Используем рефлексию для извлечения значения "Status"
                var statusProperty = selectedItem.GetType().GetProperty("Status");
                if (statusProperty != null)
                {
                    string statusName = statusProperty.GetValue(selectedItem)?.ToString();
                    StatusTextBox.Text = statusName; // Устанавливаем значение в TextBox
                }
            }
        }

        private void Filter_click(object sender, RoutedEventArgs e)
        {
            // Получаем текст из FilterTextBox
            string filterText = FilterTextBox.Text;

            // Перезагружаем данные с фильтром
            LoadData(filterText);
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new WorkerPage());
        }

        private void Status_Сlick(object sender, RoutedEventArgs e)
        {
            // Проверяем, есть ли выбранный элемент в DataGrid
            var selectedItem = dg.SelectedItem;
            if (selectedItem == null)
            {
                MessageBox.Show("Выберите строку для изменения статуса.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            // Получаем новое значение статуса из TextBox
            string newStatusName = StatusTextBox.Text;

            if (string.IsNullOrWhiteSpace(newStatusName))
            {
                MessageBox.Show("Поле статуса не может быть пустым.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            // Извлекаем ID статуса и обновляем его в базе данных
            var statusIDProperty = selectedItem.GetType().GetProperty("StatusID");
            if (statusIDProperty != null)
            {
                int statusID = (int)statusIDProperty.GetValue(selectedItem);

                // Обновляем запись в таблице Status
                var statusToUpdate = context.Status.FirstOrDefault(s => s.status_id == statusID);
                if (statusToUpdate != null)
                {
                    statusToUpdate.status_name = newStatusName;
                    context.SaveChanges(); // Сохраняем изменения в базе данных

                    // Перезагружаем данные в DataGrid
                    LoadData();
                    MessageBox.Show("Статус успешно обновлён.", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else
                {
                    MessageBox.Show("Статус не найден.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }
    }
}



